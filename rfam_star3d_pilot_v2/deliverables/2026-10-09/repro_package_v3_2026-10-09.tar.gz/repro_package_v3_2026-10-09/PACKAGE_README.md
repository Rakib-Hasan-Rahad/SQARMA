# Reproducibility package, SQARMA Rfam-seed vs original STAR3D pilot (v3, 2026-10-09)

Source commit: c972fec20637e4cff2a3c4d871676a9272967eb9 (branch v3-session-2026-10-09). Files: 1619 committed study files (git ls-files).
Environment: requirements.lock.txt (Python 3.13; FR3D-python @ 288f98ccfd72dc6d88036c124605c05ce623b1b7);
STAR3D runtime image built from scripts/Dockerfile.star3d (ubuntu:22.04, openjdk-8, linux/amd64).

NOT included (third-party or large; retrieve and verify sha256 from metadata/sources_manifest.tsv):
- STAR3D v1.2: http://genome.ucf.edu/STAR3D/STAR3D_v1.2.tar.gz
  sha256 c9da44059d9cfc40828e798ebd4f6194c55415e17aaae7d90ac0f849ec2ed946 -> inputs/software/
- mmCIF coordinates: URLs + sha256 in metadata/sources_manifest.tsv (inputs/structures/mmcif/)
- Rfam 15.1 Rfam.3d.seed.gz (Survey B): https://ftp.ebi.ac.uk/pub/databases/Rfam/15.1/Rfam.3d.seed.gz
  sha256 4055ce87a369794a1e4455badcaf7c3bc3a7a524368b5b249e34b2a8d2e8146f -> inputs/rfam_survey_b/
- Literature texts (copyright), NCBI genomes (re-fetch by accession listed in review/*exact_source*.tsv).

Rerun: see README.md "Rerun by stage"; tests: python -m pytest -q tests (51 expected to pass).
Checksums of every file in this package: SHA256SUMS.
