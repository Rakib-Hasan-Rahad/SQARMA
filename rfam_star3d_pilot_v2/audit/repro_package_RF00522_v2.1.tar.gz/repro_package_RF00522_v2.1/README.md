# Reproducibility package: RF00522 7REX-row candidate (v2.1)
Contents: pinned Rfam.seed.gz 15.1 + derived row excerpt; pinned mmCIF (3FU2, 6VUI, 7REX); STAR3D inputs and
conversion maps; residue crosswalk; reference pairs/gaps; STAR3D raw outputs (.aln, superposition PDB, npk.ct, mca,
stdout/stderr) for the 3 preQ1 pairs; run manifest rows; FR3D raw + normalized annotations + provenance sidecars;
candidate evidence; anchor fits; figures; fresh-reproduction summary; exact-source checks; source manifest subset.
NOT included: STAR3D distribution (third-party MC-Annotate/RemovePseudoknots binaries; URL + sha256 in manifest),
reference genomes (re-fetch via NCBI efetch accessions in exact_source_check.tsv), paper texts.
Verify: `shasum -a 256 -c SHA256SUMS`. Produced by an AI agent; no human review claimed.
